Thank you for downloading Mastering MSU, the Missouri State University.

Installation:
-Place the Mastering MSU folder in any location.
-Copy the Mastering MSU shortcut to your desktop.