Thank you for downloading Mastering MSU, the Missouri State University.

Installation:
-Place the Mastering MSU folder in any location.
-Open the Mastering MSU folder and find msu_game.exe
-Right-click msu_game.exe and create shortcut.
-Copy the Mastering MSU shortcut to your desktop.

Enjoy the game!