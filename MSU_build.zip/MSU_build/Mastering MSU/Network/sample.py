'''
Use this to see a sample send command
I still need to expand to allow multiple args
'''

from Client_1 import *

print("imported client")
command = input("enter cmd: ")
send(command)
